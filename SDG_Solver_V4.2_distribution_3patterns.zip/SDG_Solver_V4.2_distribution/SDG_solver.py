#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SDG Solver - beginner-friendly command interface

Usage:
    python SDG_solver.py [-t] sdg_file pattern_file

Example:
    python SDG_solver.py -t sdg1.data pattern1.data

Data format
-----------
SDG file (before '*'):
    node_id  node_name  sensor_flag  origin_flag  [host_id]

SDG file (after '*'):
    from_node_id  to_node_id  sign

Pattern file:
    node_name  sign  [time]

Rules:
- '#' starts a comment. Full-line and end-of-line comments are supported.
- Blank lines are ignored.
- '*' separates NODE definitions from EDGE definitions.
- sign is one of +, -, 0.
- sensor_flag: S means the node may appear in the pattern file.
- origin_flag: O means the node may be reported as a ROOT candidate.
- host_id and time are optional. They are used for cyber cases with time ordering.
"""

import os
import sys
from datetime import datetime, timezone

PROGRAM_VERSION = "V4.2-simple-data-interface"
CLOCK_EPSILON_SEC = 1.0


class InputError(Exception):
    pass


def usage():
    print("Usage:")
    print("  python SDG_solver.py [-t] sdg_file pattern_file")
    print()
    print("Example:")
    print("  python SDG_solver.py -t sdg1.data pattern1.data")


def fail(message):
    print("ERROR:", message)
    sys.exit(1)


def clean_line(raw):
    """Remove comments and surrounding whitespace."""
    return raw.split("#", 1)[0].strip()


def parse_time(s, filename, line_no):
    s = (s or "").strip()
    if s == "":
        return None
    try:
        if s.endswith("Z"):
            s = s[:-1] + "+00:00"
        dt = datetime.fromisoformat(s)
        # Normalize all timestamps to naive UTC so offset-aware and offset-free
        # inputs can be compared safely. Offset-free times are treated as UTC.
        if dt.tzinfo is not None:
            dt = dt.astimezone(timezone.utc).replace(tzinfo=None)
        return dt
    except ValueError:
        raise InputError(
            f'{filename}, line {line_no}: invalid time "{s}". '
            "Use ISO format, for example 2026-10-26T09:15:00 or 2026-10-26T09:15:00Z."
        )


def read_sdg_file(filename):
    if not os.path.isfile(filename):
        raise InputError(f'File "{filename}" was not found.')

    nodes_raw = []
    edges_raw = []
    section = "node"
    separator_seen = False

    with open(filename, "r", encoding="utf-8-sig") as f:
        for line_no, raw in enumerate(f, start=1):
            line = clean_line(raw)
            if not line:
                continue
            if line == "*":
                if separator_seen:
                    raise InputError(f'{filename}, line {line_no}: duplicate "*" separator.')
                separator_seen = True
                section = "edge"
                continue

            fields = line.split()
            if section == "node":
                if len(fields) not in (4, 5):
                    raise InputError(
                        f"{filename}, line {line_no}: NODE must have 4 or 5 fields:\n"
                        "  node_id node_name sensor_flag origin_flag [host_id]\n"
                        f"  input: {line}"
                    )
                nodes_raw.append((line_no, fields))
            else:
                if len(fields) != 3:
                    raise InputError(
                        f"{filename}, line {line_no}: EDGE must have 3 fields:\n"
                        "  from_node_id to_node_id sign\n"
                        f"  input: {line}"
                    )
                edges_raw.append((line_no, fields))

    if not separator_seen:
        raise InputError(f'{filename}: "*" separator between NODE and EDGE definitions is missing.')
    if not nodes_raw:
        raise InputError(f"{filename}: no NODE definitions were found.")
    if not edges_raw:
        raise InputError(f"{filename}: no EDGE definitions were found.")

    ext_id_to_index = {}
    node_name_to_index = {}
    node_id = []
    node_name = []
    node_sensor = []
    node_origin_allowed = []
    node_host = []

    for line_no, fields in nodes_raw:
        id_text, name, sensor_text, origin_text = fields[:4]
        host = fields[4] if len(fields) == 5 else ""

        try:
            ext_id = int(id_text)
        except ValueError:
            raise InputError(f'{filename}, line {line_no}: node_id "{id_text}" is not an integer.')

        if ext_id in ext_id_to_index:
            raise InputError(f"{filename}, line {line_no}: duplicate node_id {ext_id}.")
        if name in node_name_to_index:
            raise InputError(f'{filename}, line {line_no}: duplicate node name "{name}".')

        sensor = sensor_text.upper() in ("S", "Y", "YES", "1")
        origin = origin_text.upper() in ("O", "Y", "YES", "1")

        # Reject obvious typos while allowing '-' or 'N' for false.
        if sensor_text.upper() not in ("S", "-", "N", "NO", "0", "Y", "YES", "1"):
            raise InputError(
                f'{filename}, line {line_no}: invalid sensor flag "{sensor_text}". '
                "Use S for sensor or - for non-sensor."
            )
        if origin_text.upper() not in ("O", "-", "N", "NO", "0", "Y", "YES", "1"):
            raise InputError(
                f'{filename}, line {line_no}: invalid origin flag "{origin_text}". '
                "Use O for ROOT-eligible or - for not eligible."
            )

        idx = len(node_name)
        ext_id_to_index[ext_id] = idx
        node_name_to_index[name] = idx
        node_id.append(ext_id)
        node_name.append(name)
        node_sensor.append(sensor)
        node_origin_allowed.append(origin)
        node_host.append(host)

    branch_start = []
    branch_end = []
    branch_sign = []

    for line_no, fields in edges_raw:
        from_text, to_text, sign = fields
        try:
            from_id = int(from_text)
            to_id = int(to_text)
        except ValueError:
            raise InputError(
                f"{filename}, line {line_no}: EDGE node IDs must be integers. input: {' '.join(fields)}"
            )

        if from_id not in ext_id_to_index:
            raise InputError(f"{filename}, line {line_no}: EDGE refers to undefined node {from_id}.")
        if to_id not in ext_id_to_index:
            raise InputError(f"{filename}, line {line_no}: EDGE refers to undefined node {to_id}.")
        if sign not in ("+", "-"):
            raise InputError(
                f'{filename}, line {line_no}: invalid EDGE sign "{sign}". Allowed signs are + and -.'
            )

        branch_start.append(ext_id_to_index[from_id])
        branch_end.append(ext_id_to_index[to_id])
        branch_sign.append(sign)

    return {
        "node_id": node_id,
        "node_name": node_name,
        "node_sensor": node_sensor,
        "node_origin_allowed": node_origin_allowed,
        "node_host": node_host,
        "node_name_to_index": node_name_to_index,
        "branch_start": branch_start,
        "branch_end": branch_end,
        "branch_sign": branch_sign,
    }


def read_pattern_file(filename, sdg):
    if not os.path.isfile(filename):
        raise InputError(f'File "{filename}" was not found.')

    n_nodes = len(sdg["node_name"])
    node_sign_measured = [""] * n_nodes
    node_time_measured = [None] * n_nodes
    node_time_text = [""] * n_nodes
    pattern_rows = []

    with open(filename, "r", encoding="utf-8-sig") as f:
        for line_no, raw in enumerate(f, start=1):
            line = clean_line(raw)
            if not line:
                continue
            fields = line.split()
            if len(fields) not in (2, 3):
                raise InputError(
                    f"{filename}, line {line_no}: pattern must have 2 or 3 fields:\n"
                    "  node_name sign [time]\n"
                    f"  input: {line}"
                )

            name, sign = fields[:2]
            time_text = fields[2] if len(fields) == 3 else ""

            if name not in sdg["node_name_to_index"]:
                raise InputError(
                    f'{filename}, line {line_no}: unknown node name "{name}". '
                    f'"{name}" is not defined in the SDG file.'
                )
            idx = sdg["node_name_to_index"][name]
            if not sdg["node_sensor"][idx]:
                raise InputError(
                    f'{filename}, line {line_no}: node "{name}" is not marked as a sensor node (S) in the SDG file.'
                )
            if sign not in ("+", "-", "0"):
                raise InputError(
                    f'{filename}, line {line_no}: invalid sign "{sign}". Allowed signs are +, -, 0.'
                )
            if node_sign_measured[idx] != "":
                raise InputError(f'{filename}, line {line_no}: node "{name}" is specified more than once.')

            t = parse_time(time_text, filename, line_no)
            node_sign_measured[idx] = sign
            node_time_measured[idx] = t
            node_time_text[idx] = time_text
            pattern_rows.append((idx, sign, time_text))

    if not pattern_rows:
        raise InputError(f"{filename}: no pattern data were found.")
    if not any(sign in ("+", "-") for _, sign, _ in pattern_rows):
        raise InputError(f"{filename}: at least one + or - observation is required for diagnosis.")

    return node_sign_measured, node_time_measured, node_time_text, pattern_rows


def parse_command_line(argv):
    show_tree = False
    files = []

    for arg in argv[1:]:
        if arg in ("-h", "--help"):
            usage()
            sys.exit(0)
        elif arg == "-t":
            show_tree = True
        elif arg.startswith("-"):
            raise InputError(f'Unknown option "{arg}".')
        else:
            files.append(arg)

    if len(files) != 2:
        usage()
        raise InputError("Specify one SDG file and one pattern file.")

    return show_tree, files[0], files[1]


# ------------------------------------------------------------
# Command / input
# ------------------------------------------------------------
try:
    SHOW_TREE, SDG_FILE, PATTERN_FILE = parse_command_line(sys.argv)
    sdg = read_sdg_file(SDG_FILE)
    (
        node_sign_measured,
        node_time_measured,
        node_time_text,
        pattern_rows,
    ) = read_pattern_file(PATTERN_FILE, sdg)
except InputError as e:
    fail(str(e))

node_id = sdg["node_id"]
node_name = sdg["node_name"]
node_sensor = sdg["node_sensor"]
node_origin_allowed = sdg["node_origin_allowed"]
node_host = sdg["node_host"]
branch_start = sdg["branch_start"]
branch_end = sdg["branch_end"]
branch_sign = sdg["branch_sign"]

N = len(node_name)
M = len(branch_start)

# ------------------------------------------------------------
# Input branches
# ------------------------------------------------------------
node_input_branch = [[] for _ in range(N)]
for j in range(M):
    node_input_branch[branch_end[j]].append(j)

# ------------------------------------------------------------
# Working arrays
# ------------------------------------------------------------
node_sign_assumed = [""] * N
node_number = [0] * N
node_input_change_flag = [0] * N
node_origin_flag = [0] * N   # 0=unchecked/not accepted, 1=checked, 2=accepted
stack = []

Measured = [i for i in range(N) if node_sign_measured[i] in ("+", "-")]


def measurement_sort_key(node):
    t = node_time_measured[node]
    if t is None:
        return (1, 0.0, node)
    return (0, t.timestamp(), node)


Measured.sort(key=measurement_sort_key)
MS = len(Measured)

# ------------------------------------------------------------
# Solver helpers
# ------------------------------------------------------------
def multiply_sign(sign1, sign2):
    return "+" if sign1 == sign2 else "-"


def allowed(node, sign):
    m = node_sign_measured[node]
    if m == "0":
        return False
    if m == "":
        return True
    return m == sign


def clear_to(mark):
    while len(stack) > mark:
        n = stack.pop()
        node_sign_assumed[n] = ""
        node_number[n] = 0
        node_input_change_flag[n] = 0


def clock_epsilon(up_node, down_node):
    hu = node_host[up_node]
    hd = node_host[down_node]
    if hu and hd and hu == hd:
        return 0.0
    return CLOCK_EPSILON_SEC


time_backtrack_count = 0


def nearest_downstream_observed():
    for n in reversed(stack):
        if node_time_measured[n] is not None:
            return n
    return None


def time_allowed_upstream_step(up_node):
    if node_time_measured[up_node] is None:
        return True
    down_obs = nearest_downstream_observed()
    if down_obs is None or down_obs == up_node:
        return True
    t_up = node_time_measured[up_node]
    t_down = node_time_measured[down_obs]
    eps = clock_epsilon(up_node, down_obs)
    return (t_up - t_down).total_seconds() <= eps


def validate_tree_time(root, branches):
    children = {}
    for b in branches:
        u = branch_start[b]
        v = branch_end[b]
        children.setdefault(u, []).append(v)

    work = [(root, None)]
    while work:
        now, last_obs = work.pop()
        current_obs = last_obs
        if node_time_measured[now] is not None:
            if last_obs is not None:
                t_up = node_time_measured[last_obs]
                t_down = node_time_measured[now]
                eps = clock_epsilon(last_obs, now)
                if (t_up - t_down).total_seconds() > eps:
                    return False
            current_obs = now
        for child in children.get(now, []):
            work.append((child, current_obs))
    return True


# ------------------------------------------------------------
# Connect m-th measured point to current tree
# ------------------------------------------------------------
def connect_measurement(m):
    global time_backtrack_count
    if m >= MS:
        return True

    start_node = Measured[m]
    start_sign = node_sign_measured[start_node]

    if node_sign_assumed[start_node] != "":
        if node_sign_assumed[start_node] != start_sign:
            return False
        return connect_measurement(m + 1)

    mark = len(stack)
    node_sign_assumed[start_node] = start_sign
    node_number[start_node] = m + 1
    node_input_change_flag[start_node] = 0
    stack.append(start_node)

    while len(stack) > mark:
        now_node = stack[-1]
        k = node_input_change_flag[now_node]

        if k >= len(node_input_branch[now_node]):
            n = stack.pop()
            node_sign_assumed[n] = ""
            node_number[n] = 0
            node_input_change_flag[n] = 0
            if len(stack) > mark:
                node_input_change_flag[stack[-1]] += 1
            continue

        b = node_input_branch[now_node][k]
        next_node = branch_start[b]
        next_sign = multiply_sign(node_sign_assumed[now_node], branch_sign[b])

        if not allowed(next_node, next_sign):
            node_input_change_flag[now_node] += 1
            continue

        if not time_allowed_upstream_step(next_node):
            time_backtrack_count += 1
            node_input_change_flag[now_node] += 1
            continue

        if node_sign_assumed[next_node] == "":
            node_sign_assumed[next_node] = next_sign
            node_number[next_node] = m + 1
            node_input_change_flag[next_node] = 0
            stack.append(next_node)
            continue

        if node_sign_assumed[next_node] == next_sign:
            if node_number[next_node] < m + 1:
                if connect_measurement(m + 1):
                    return True
                clear_to(len(stack))

        node_input_change_flag[now_node] += 1

    clear_to(mark)
    return False


# ------------------------------------------------------------
# Search ROOT candidates
# ------------------------------------------------------------
solutions = []

if MS > 0:
    first_node = Measured[0]
    first_sign = node_sign_measured[first_node]

    node_sign_assumed[first_node] = first_sign
    node_number[first_node] = 1
    node_input_change_flag[first_node] = 0
    stack.append(first_node)

    while stack:
        root = stack[-1]

        # Only O-marked nodes may be reported as ROOT candidates.
        if node_origin_allowed[root] and node_origin_flag[root] != 2:
            node_origin_flag[root] = 1
            root_mark = len(stack)

            if connect_measurement(1):
                solution_sign = list(node_sign_assumed)
                solution_number = list(node_number)
                solution_branch = []

                for i in range(N):
                    if node_number[i] > 0 and i != root:
                        k = node_input_change_flag[i]
                        if k < len(node_input_branch[i]):
                            b = node_input_branch[i][k]
                            if b not in solution_branch:
                                solution_branch.append(b)

                if validate_tree_time(root, solution_branch):
                    node_origin_flag[root] = 2
                    solutions.append([
                        root,
                        node_sign_assumed[root],
                        solution_sign,
                        solution_number,
                        solution_branch,
                    ])
                else:
                    node_origin_flag[root] = 0

                clear_to(root_mark)
            else:
                node_origin_flag[root] = 0

        now_node = stack[-1]
        k = node_input_change_flag[now_node]

        if k >= len(node_input_branch[now_node]):
            n = stack.pop()
            node_sign_assumed[n] = ""
            node_number[n] = 0
            node_input_change_flag[n] = 0
            if stack:
                node_input_change_flag[stack[-1]] += 1
            continue

        b = node_input_branch[now_node][k]
        next_node = branch_start[b]
        next_sign = multiply_sign(node_sign_assumed[now_node], branch_sign[b])

        if not allowed(next_node, next_sign):
            node_input_change_flag[now_node] += 1
            continue

        if not time_allowed_upstream_step(next_node):
            time_backtrack_count += 1
            node_input_change_flag[now_node] += 1
            continue

        if node_sign_assumed[next_node] == "":
            node_sign_assumed[next_node] = next_sign
            node_number[next_node] = 1
            node_input_change_flag[next_node] = 0
            stack.append(next_node)
            continue

        node_input_change_flag[now_node] += 1

# ------------------------------------------------------------
# Output helpers
# ------------------------------------------------------------
def output(line=""):
    print(line)


def tree_lines(root, signs, branches):
    children = {}
    for b in branches:
        children.setdefault(branch_start[b], []).append((branch_end[b], b))

    lines = []
    visited = set()

    def walk(node, prefix="", is_last=True, is_root=False):
        if is_root:
            lines.append(f"{node_name[node]}({signs[node]})")
        else:
            connector = "└─ " if is_last else "├─ "
            lines.append(prefix + connector + f"{node_name[node]}({signs[node]})")

        if node in visited:
            lines[-1] += " [already shown]"
            return
        visited.add(node)

        kids = children.get(node, [])
        for pos, (child, _b) in enumerate(kids):
            last = pos == len(kids) - 1
            child_prefix = prefix + ("   " if is_last else "│  ")
            if is_root:
                child_prefix = ""
            walk(child, child_prefix, last, False)

    walk(root, is_root=True)
    return lines


# ------------------------------------------------------------
# Result display
# ------------------------------------------------------------
output("SDG Solver")
output("==========")
output(f"Program version : {PROGRAM_VERSION}")
output(f"SDG file        : {SDG_FILE}")
output(f"Pattern file    : {PATTERN_FILE}")
output()
output(f"Nodes : {N}")
output(f"Edges : {M}")
output()
output("Observed pattern")
for idx, sign, t_text in pattern_rows:
    extra = f"  {t_text}" if t_text else ""
    output(f"  {node_name[idx]}  {sign}{extra}")
output()
output("Cause candidates")

if not solutions:
    output("  None")
else:
    for no, solution in enumerate(solutions, start=1):
        root, root_sign, signs, numbers, branches = solution
        output(f"  {no}. {node_name[root]}({root_sign})")

if SHOW_TREE:
    output()
    if not solutions:
        output("Effective rooted tree")
        output("  None")
    else:
        for no, solution in enumerate(solutions, start=1):
            root, root_sign, signs, numbers, branches = solution
            output(f"Effective rooted tree {no}")
            for line in tree_lines(root, signs, branches):
                output("  " + line)
            output()

# Time diagnostic appears only when time data are actually used.
if any(t is not None for t in node_time_measured):
    output(f"Time-order backtracks : {time_backtrack_count}")
    output(f"Cross-host clock tolerance : {CLOCK_EPSILON_SEC} sec")
    output()

