SDG Solver V4.2  2タンク・デモ

【最初の実行】
1. ZIPファイルを展開してください。
2. run.bat をダブルクリックしてください。
3. 1～3のパターンを選んでください。

【3つの観測パターン】
pattern1.data : F1が低下する例（詰まり）
                期待されるROOT = F1(-)

pattern2.data : F0が増加する例（流入増加）
                期待されるROOT = F0(+)

pattern3.data : F2が低下する例（出口側の抵抗増加）
                期待されるROOT = F2(-)

同じSDGモデル（sdg1.data）を使い、観測パターンだけを変えると、
原因候補と有効根付き木が変わることを確認できます。

【コマンドで実行する場合】
py SDG_solver.py -t sdg1.data pattern1.data
py SDG_solver.py -t sdg1.data pattern2.data
py SDG_solver.py -t sdg1.data pattern3.data

python コマンドを使う環境では py の代わりに python を使ってください。

結果は標準出力にだけ表示します。自動保存はしません。
必要な場合だけ、次のように保存できます。
py SDG_solver.py -t sdg1.data pattern1.data > result.txt
