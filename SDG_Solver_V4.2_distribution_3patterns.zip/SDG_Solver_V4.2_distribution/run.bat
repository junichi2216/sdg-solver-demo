@echo off
chcp 65001 >nul
cd /d "%~dp0"

echo ========================================
echo   SDG Solver V4.2 - 2 Tank Demo
echo ========================================
echo.
echo  1: Pattern 1  F1 decreases  ^(clogging^)
echo  2: Pattern 2  F0 increases  ^(inlet increase^)
echo  3: Pattern 3  F2 decreases  ^(outlet restriction^)
echo.
set /p P=Select pattern [1-3]: 
if "%P%"=="" set P=1
if not exist "pattern%P%.data" (
  echo Invalid selection.
  pause
  exit /b 1
)

where py >nul 2>nul
if %errorlevel%==0 (
    py SDG_solver.py -t sdg1.data pattern%P%.data
) else (
    where python >nul 2>nul
    if %errorlevel%==0 (
        python SDG_solver.py -t sdg1.data pattern%P%.data
    ) else (
        echo Python 3 was not found.
        echo Install Python 3 and run this file again.
    )
)

echo.
echo Press any key to close.
pause >nul
