SDG Solver V4.2 - Two-Tank Demo

Windows quick start:
1. Extract the ZIP file.
2. Double-click run.bat.
3. Choose Pattern 1, 2, or 3.

Included patterns:
  pattern1.data : F1 decreases (clogging example) -> expected ROOT F1(-)
  pattern2.data : F0 increases (inlet flow increase) -> expected ROOT F0(+)
  pattern3.data : F2 decreases (outlet-side restriction) -> expected ROOT F2(-)

Command line examples:
  py SDG_solver.py -t sdg1.data pattern1.data
  py SDG_solver.py -t sdg1.data pattern2.data
  py SDG_solver.py -t sdg1.data pattern3.data

or use python instead of py.

The solver writes results to standard output only. To save them:
  py SDG_solver.py -t sdg1.data pattern1.data > result.txt

Python 3 is required. Research/educational demo.
